var class_dominio =
[
    [ "getValor", "class_dominio.html#adc86858ec8f9d7d91a0d8498f3614864", null ],
    [ "setValor", "class_dominio.html#ad6cdf0af925aca18d7b0ec660922567b", null ]
];