var class_hospedagem =
[
    [ "getAvaliacao", "class_hospedagem.html#a25d434bffc9f888c7d138788a72e6304", null ],
    [ "getCodigo", "class_hospedagem.html#a0bc571395f18c1c0a62409a0f7a0a7f1", null ],
    [ "getDiaria", "class_hospedagem.html#a0b69b10783f7795dccef73dc2d27efb0", null ],
    [ "getNome", "class_hospedagem.html#acd15abdd2f7f04dcd5f93c466e9f9800", null ],
    [ "setAvaliacao", "class_hospedagem.html#a02ead6490956187fb6d58400426b0e49", null ],
    [ "setCodigo", "class_hospedagem.html#a6a26e1ec207fb7bccce543e9e044aa33", null ],
    [ "setDiaria", "class_hospedagem.html#a5467ac83d9cdc97480a40d5e9498c3eb", null ],
    [ "setNome", "class_hospedagem.html#a1cd604eb42251029a565c6a40784cd3a", null ]
];