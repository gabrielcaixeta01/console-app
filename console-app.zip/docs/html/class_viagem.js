var class_viagem =
[
    [ "getAvaliacao", "class_viagem.html#a42db61ac0f02f1a84d7ca399b808577c", null ],
    [ "getCodigo", "class_viagem.html#aaf9cbace04be90c00e62d7b819abddd4", null ],
    [ "getNome", "class_viagem.html#a94988065b6782f723dfed72bd287c934", null ],
    [ "setAvaliacao", "class_viagem.html#a9e28738038c2ef066ebc0f35901d1104", null ],
    [ "setCodigo", "class_viagem.html#a5a05f711662d043b598549ff511d47d1", null ],
    [ "setNome", "class_viagem.html#a4b925d32bfa7f2df6a22b3ae96793b45", null ]
];