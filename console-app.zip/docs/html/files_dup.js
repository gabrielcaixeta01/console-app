var files_dup =
[
    [ "dominios.hpp", "dominios_8hpp.html", "dominios_8hpp" ],
    [ "entidades.hpp", "entidades_8hpp.html", "entidades_8hpp" ],
    [ "testesDominio.hpp", "testes_dominio_8hpp.html", "testes_dominio_8hpp" ],
    [ "testesEntidade.hpp", "testes_entidade_8hpp.html", "testes_entidade_8hpp" ]
];