var hierarchy =
[
    [ "Atividade", "class_atividade.html", null ],
    [ "Conta", "class_conta.html", null ],
    [ "Destino", "class_destino.html", null ],
    [ "Dominio", "class_dominio.html", [
      [ "Avaliacao", "class_avaliacao.html", null ],
      [ "Codigo", "class_codigo.html", null ],
      [ "Data", "class_data.html", null ],
      [ "Dinheiro", "class_dinheiro.html", null ],
      [ "Duracao", "class_duracao.html", null ],
      [ "Horario", "class_horario.html", null ],
      [ "Nome", "class_nome.html", null ],
      [ "Senha", "class_senha.html", null ]
    ] ],
    [ "Hospedagem", "class_hospedagem.html", null ],
    [ "TUAtividade", "class_t_u_atividade.html", null ],
    [ "TUAvaliacao", "class_t_u_avaliacao.html", null ],
    [ "TUCodigo", "class_t_u_codigo.html", null ],
    [ "TUConta", "class_t_u_conta.html", null ],
    [ "TUData", "class_t_u_data.html", null ],
    [ "TUDestino", "class_t_u_destino.html", null ],
    [ "TUDinheiro", "class_t_u_dinheiro.html", null ],
    [ "TUDuracao", "class_t_u_duracao.html", null ],
    [ "TUHorario", "class_t_u_horario.html", null ],
    [ "TUHospedagem", "class_t_u_hospedagem.html", null ],
    [ "TUNome", "class_t_u_nome.html", null ],
    [ "TUSenha", "class_t_u_senha.html", null ],
    [ "TUViagem", "class_t_u_viagem.html", null ],
    [ "Viagem", "class_viagem.html", null ]
];