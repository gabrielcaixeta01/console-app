var indexSectionsWithContent =
{
  0: "acdefghnoprstuv",
  1: "acdhnstv",
  2: "det",
  3: "grs",
  4: "fsv",
  5: "act"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Páginas"
};

