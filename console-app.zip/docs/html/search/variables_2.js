var searchData=
[
  ['valor_5fvalido_5fcodigo_0',['VALOR_VALIDO_CODIGO',['../testes_entidade_8hpp.html#a1732b7aa93a8da3a7c38a12a4b7a1a8c',1,'testesEntidade.cpp']]],
  ['valor_5fvalido_5fsenha_1',['VALOR_VALIDO_SENHA',['../testes_entidade_8hpp.html#ab8561d155bc688e286ffe22ebdd0da3f',1,'testesEntidade.cpp']]]
];
