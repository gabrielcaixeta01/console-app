var searchData=
[
  ['funcionalidades_0',['Funcionalidades',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
