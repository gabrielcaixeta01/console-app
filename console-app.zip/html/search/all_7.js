var searchData=
[
  ['modularização_20e_20separação_20de_20responsabilidades_0',['Modularização e Separação de Responsabilidades',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
