var searchData=
[
  ['regras_20de_20negócio_0',['Regras de Negócio',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['responsabilidades_1',['Modularização e Separação de Responsabilidades',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
