var searchData=
[
  ['separação_20de_20responsabilidades_0',['Modularização e Separação de Responsabilidades',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['serviço_20tt_20is_20tt_1',['Interfaces de Serviço (&lt;tt&gt;IS&lt;/tt&gt;)',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];
