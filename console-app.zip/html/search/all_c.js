var searchData=
[
  ['tp1_0',['Console App - TP1',['../md__r_e_a_d_m_e.html',1,'']]],
  ['tt_1',['tt',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'Interfaces de Apresentação (&lt;tt&gt;IA&lt;/tt&gt;)'],['../md__r_e_a_d_m_e.html#autotoc_md8',1,'Interfaces de Serviço (&lt;tt&gt;IS&lt;/tt&gt;)']]],
  ['tt_20ia_20tt_2',['Interfaces de Apresentação (&lt;tt&gt;IA&lt;/tt&gt;)',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['tt_20is_20tt_3',['Interfaces de Serviço (&lt;tt&gt;IS&lt;/tt&gt;)',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];
